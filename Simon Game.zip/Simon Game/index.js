
buttonColors=["red", "blue", "green", "yellow"];   // buttons ke colors
var gamepattern=[]; //jo program generate kre usko save krne ke liye
var userClickedPattern=[]; // jo user generate kre usko save krne ke liye

//program jo next sequence generate kre uske liye
function nextSequence(){
   level = level+1;//jo level starting m 0 h usko badhao aur har baar jab bhi user sahi button seq dabaye tab badhao
   userClickedPattern=[];//kyu ki agar user clicked pattern empty krenege tabhi player wapas game pattern ke barabar le jayega .
    var randomnumber= Math.round(Math.random()*4); // random number generate krenge
    var randomchosencolor=buttonColors[randomnumber]; // us random number ke barabar wala color choose krenge
     gamepattern.push((randomchosencolor)); //aur us color ko prog generated game pattern m dalenege
    $("#"+randomchosencolor).fadeIn(100).fadeOut(100).fadeIn(100);  // ye animation ke liye h taki program generateed pattern user ko dikahi de
    playsound(randomchosencolor); //play sound function call kr rhe h jo sound play krega aur parameter m color ka naam send krenge
    $("#level-title").text("level "+level); //heading m level show krenge
}

//user ne poora sequence m sahi press kia h ki nhi ye check krenge
function checkAnswer(currentlevel){  //ye function user generated pattern ka last index number lega

    if(gamepattern[currentlevel]===userClickedPattern[currentlevel]) //aur usko prog generated seq ke last color se match krega  kyu ki agar last wala color hi match nhi kia toh direct out h
      {
          //agar match krta h toh user aur prog generated seq ka length check krega kyu ki agar same color wala pehel ka dabaya ho toh length kum hoga user generated wale ka
        if(userClickedPattern.length === gamepattern.length){
            setTimeout(function(){ //1000 milisec ke baad dusra color generate krenge agar sab sahi hua toh
              nextSequence(); //nextSequence() function ko call krenge jo next color ko randomly generate krenga aur level badheyga
            },1000);

        }
      }else{ //agr galat seq press krta h user toh
        playsound("wrong"); //wrong wala tne play hoga
        $("body").addClass("game-over"); //bdy ka color red ho jeyga

        setTimeout(function(){ //aur 300 ms ke baad fir se normal
          $("body").removeClass("game-over");
        },300); //aur normal krne ke liye restart ka function call krenge
        startOver();
      }


}

//ye function sirf prog gene seq ko null krega aur level ko 0 krega aur started ko false
function startOver(){

  level=0;
  started=false;
  $("#level-title").text("Press A Key to Start");
  gamepattern=[];

}

var started = false; //started sabse pehele false rehga kyu ki match start nhi hua
var level = 0; //aur level bhi 0 rehega
$(document).keydown(function(){ // koi bbhi key press hota h keyboard m toh ye ckeck krega
      if(!started){ //agar started true nhi h means start nhi hua h toh
        nextSequence();//prog seq generate krega
        started = true; //aur start ko true krega
      }
});

//jab bhi button press krega user toh ye function event handle krega
$(".btn").click(function(event){
    var userChosenColour = $(this).attr('id'); //jo button dabaya uska id lega
    userClickedPattern.push(userChosenColour); //uska color ko user gene seq m dalega
    checkAnswer(userClickedPattern.length-1); //uska ans check krega length bhej ke
    playsound(userChosenColour); //sound play krega
    animatePress(userChosenColour); //aur animation dlega jo button daba usme
});

//ye sound play hone ke liye
function playsound(name){

  var audio=new Audio("sounds/"+ name + ".mp3");
  audio.play();

}

//ye jab bhi user button press krega toh animate hone ke liye
function animatePress(currentColor){

  $("#"+currentColor).addClass("pressed");
//aur thodi der baad normal ho jane ke liye
  setTimeout(function(){

    $("#"+ currentColor).removeClass("pressed");
  },100);

}
